import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import plotly.graph_objects as go

st.set_page_config(
    page_title="DiPol Risk AI",
    page_icon="🧠",
    layout="wide"
)

st.markdown("""
<style>
.stApp {
    background: linear-gradient(135deg, #0f172a 0%, #111827 45%, #1e1b4b 100%);
    color: white;
}
.main-title {
    font-size: 52px;
    font-weight: 900;
    text-align: center;
    background: linear-gradient(90deg, #a78bfa, #38bdf8, #f472b6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 0px;
}
.sub-title {
    text-align: center;
    color: #cbd5e1;
    font-size: 18px;
    margin-bottom: 35px;
}
.card {
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: 22px;
    padding: 24px;
    box-shadow: 0 12px 35px rgba(0,0,0,0.35);
}
.big-number {
    font-size: 48px;
    font-weight: 900;
}
.safe {color:#22c55e;}
.mid {color:#facc15;}
.risk {color:#fb7185;}
.footer {
    text-align:center;
    color:#94a3b8;
    margin-top:40px;
    font-size:14px;
}
</style>
""", unsafe_allow_html=True)

# Demo eğitim verisi oluşturma
@st.cache_data
def create_demo_data(seed=42):
    np.random.seed(seed)
    n = 900
    income = np.random.randint(8000, 90000, n)
    debt = np.random.randint(0, 70000, n)
    payment_score = np.random.randint(20, 100, n)
    age = np.random.randint(18, 65, n)
    work_year = np.random.randint(0, 30, n)
    late_payments = np.random.randint(0, 10, n)
    job_type = np.random.choice(["Öğrenci", "Çalışan", "Serbest", "İşsiz"], n, p=[0.18, 0.55, 0.17, 0.10])

    risk_point = (
        (debt / np.maximum(income, 1)) * 38
        + late_payments * 6
        + (100 - payment_score) * 0.8
        - work_year * 0.9
    )
    risk_point += np.where(job_type == "İşsiz", 20, 0)
    risk_point += np.where(job_type == "Öğrenci", 8, 0)
    target = np.where(risk_point > 55, 1, 0)

    return pd.DataFrame({
        "gelir": income,
        "borc": debt,
        "odeme_puani": payment_score,
        "yas": age,
        "calisma_yili": work_year,
        "gec_odeme": late_payments,
        "meslek": job_type,
        "risk": target
    })

@st.cache_resource
def train_model():
    df = create_demo_data()
    le = LabelEncoder()
    df["meslek_encoded"] = le.fit_transform(df["meslek"])

    X = df[["gelir", "borc", "odeme_puani", "yas", "calisma_yili", "gec_odeme", "meslek_encoded"]]
    y = df["risk"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)

    model = RandomForestClassifier(n_estimators=120, random_state=42, max_depth=7)
    model.fit(X_train, y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    return model, le, acc, df

model, le, acc, demo_df = train_model()

st.markdown('<h1 class="main-title">DiPol Risk AI</h1>', unsafe_allow_html=True)
st.markdown('<p class="sub-title">Makine öğrenmesi destekli modern risk analiz paneli</p>', unsafe_allow_html=True)

with st.sidebar:
    st.title("⚙️ Analiz Formu")
    st.caption("Bilgileri gir, sistem risk skorunu hesaplasın.")

    gelir = st.number_input("Aylık Gelir (₺)", min_value=0, max_value=200000, value=25000, step=1000)
    borc = st.number_input("Toplam Borç (₺)", min_value=0, max_value=300000, value=15000, step=1000)
    odeme_puani = st.slider("Ödeme Düzeni Puanı", 0, 100, 75)
    yas = st.slider("Yaş", 18, 70, 25)
    calisma_yili = st.slider("Çalışma / Gelir Süresi (Yıl)", 0, 40, 2)
    gec_odeme = st.slider("Geç Ödeme Sayısı", 0, 15, 1)
    meslek = st.selectbox("Durum / Meslek", ["Öğrenci", "Çalışan", "Serbest", "İşsiz"])
    analiz = st.button("🚀 Risk Analizi Yap", use_container_width=True)

# Varsayılan olarak da analiz göster
try:
    meslek_encoded = le.transform([meslek])[0]
except ValueError:
    meslek_encoded = 0

input_data = pd.DataFrame([{
    "gelir": gelir,
    "borc": borc,
    "odeme_puani": odeme_puani,
    "yas": yas,
    "calisma_yili": calisma_yili,
    "gec_odeme": gec_odeme,
    "meslek_encoded": meslek_encoded
}])

risk_probability = model.predict_proba(input_data)[0][1]
risk_score = int(risk_probability * 100)

if risk_score < 35:
    label = "Düşük Risk"
    css_class = "safe"
    yorum = "Profil genel olarak güvenli görünüyor. Gelir-borç dengesi ve ödeme düzeni olumlu."
elif risk_score < 65:
    label = "Orta Risk"
    css_class = "mid"
    yorum = "Bazı risk sinyalleri var. Borç oranı, ödeme puanı veya geç ödeme sayısı iyileştirilebilir."
else:
    label = "Yüksek Risk"
    css_class = "risk"
    yorum = "Risk seviyesi yüksek görünüyor. Borç yükü, düzensiz ödeme veya gelir süresi sonucu etkiliyor."

col1, col2, col3 = st.columns([1.1, 1, 1])

with col1:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("📊 Risk Skoru")
    st.markdown(f'<div class="big-number {css_class}">%{risk_score}</div>', unsafe_allow_html=True)
    st.markdown(f"### {label}")
    st.write(yorum)
    st.markdown("</div>", unsafe_allow_html=True)

with col2:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("🧠 Model Bilgisi")
    st.metric("Algoritma", "Random Forest")
    st.metric("Demo Doğruluk", f"%{acc*100:.1f}")
    st.caption("Bu proje eğitim/demo amaçlıdır. Gerçek finansal karar sistemi değildir.")
    st.markdown("</div>", unsafe_allow_html=True)

with col3:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("✅ Öneriler")
    if risk_score < 35:
        st.success("Mevcut profil iyi. Düzenli ödeme alışkanlığı korunmalı.")
    elif risk_score < 65:
        st.warning("Borç azaltma ve ödeme düzenini güçlendirme önerilir.")
    else:
        st.error("Önce borç/gelir dengesi ve geç ödemeler iyileştirilmeli.")
    st.markdown("</div>", unsafe_allow_html=True)

st.write("")
left, right = st.columns([1, 1])

with left:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("📈 Risk Göstergesi")
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=risk_score,
        number={"suffix": "%"},
        gauge={"axis": {"range": [0, 100]}, "bar": {"thickness": 0.28}}
    ))
    fig.update_layout(height=300, margin=dict(l=20, r=20, t=20, b=20), paper_bgcolor="rgba(0,0,0,0)", font={"color":"white"})
    st.plotly_chart(fig, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

with right:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("🔍 Girilen Bilgiler")
    st.dataframe(pd.DataFrame({
        "Alan": ["Gelir", "Borç", "Ödeme Puanı", "Yaş", "Çalışma Yılı", "Geç Ödeme", "Meslek"],
        "Değer": [f"{gelir:,} ₺", f"{borc:,} ₺", odeme_puani, yas, calisma_yili, gec_odeme, meslek]
    }), use_container_width=True, hide_index=True)
    st.markdown("</div>", unsafe_allow_html=True)

st.markdown('<div class="footer">DiPol Risk AI • Streamlit + Python + Random Forest • Render uyumlu proje</div>', unsafe_allow_html=True)
