# DiPol Risk AI

Streamlit + Python + Random Forest ile hazırlanmış modern risk analiz web uygulaması.

## Yerelde Çalıştırma
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Render Deploy
- New Web Service oluştur
- GitHub repo seç
- Build Command: `pip install -r requirements.txt`
- Start Command: `streamlit run app.py --server.port=$PORT --server.address=0.0.0.0`

## Not
Bu proje eğitim/demo amaçlıdır. Gerçek finansal karar sistemi değildir.
